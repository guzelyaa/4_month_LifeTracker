package com.example.a1hw4monthlifetracker

import android.service.autofill.CustomDescription

data class BoardModel(
    val image: Int,
    val description: String,
    val button: String
)