package com.example.a1hw4monthlifetracker

interface ItemOnClickListener {
    fun itemClick()
    fun btnClick1page()
    fun btnClick2page()
}